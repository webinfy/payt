<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class WebfrontsController extends AppController {

    public function initialize() {
        parent::initialize();

        // Load Models
        $this->loadModel('Webfronts');
        $this->loadModel('Users');
        $this->loadModel('Payments');
        $this->loadModel('Validations');
        $this->loadModel('UploadedPaymentFiles');
        $this->loadModel('PaymentGatewayResponses');

        // Load Components
        $this->loadComponent('Custom');
        $this->loadComponent('Paginator');

        // Set Layout
        $this->viewBuilder()->setLayout('');
    }

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $authAllow = ['viewWebfront', 'previewInvoice', 'payuResponse', 'razorPayResponse', 'payNow', 'downloadReceipt', 'payuAdvWebfrontForm', 'ajaxCheckEmailAvail'];
        $this->Auth->allow($authAllow);
    }

    /*
     * Developer   :  Paratap Kishore Swain
     * Date        :  17th Oct 2018
     * Description :  View webfront public page.
     */

    public function viewWebfront($url) {
        
        $contain = ['Merchants', 'Users', 'WebfrontFields', 'WebfrontFields.WebfrontFieldValues', 'WebfrontPaymentAttributes'];
        $query = $this->Webfronts->find()->where(['Webfronts.url' => $url])->contain($contain);
               
        if ($query->count()) {
            $webfront = $query->first();            
        } else {
            throw \Cake\Datasource\Exception\PageOutOfBoundsException;
        }

        if ($this->request->is('post')) {
            
            $reference_number = trim($this->request->getData(['reference_number']));
            
            $conditions = ['Payments.reference_number' => $reference_number, 'Payments.status' => '0', 'Payments.webfront_id' => $webfront->id];
            $payments = $this->Payments->find('all')->where($conditions);

            if ($payments->count() == 1) {
                return $this->redirect(HTTP_ROOT . "webfronts/preview-invoice/" . $payments->first()->uniq_id);
            } else {

                $conditions = ['Payments.reference_number' => $reference_number, 'Payments.webfront_id' => $webfront->id];
                $payments = $this->Payments->find('all')->where($conditions)->contain(['UploadedPaymentFiles'])->order(['Payments.id' => 'DESC']);

                if ($payments->count() > 0) {
                    $this->set(compact('payments'));
                } else {
                    $referenceNumberExist = $this->Users->find('all')->where(['reference_number' => $reference_number])->count();
                    if ($referenceNumberExist) {
                        $error = "No record found for the Reference No. \"<b>{$reference_number}</b>\"";
                    } else {
                        $error = "This Reference No. \"<b>{$reference_number}</b>\" is not registered";
                    }
                    $this->set(compact('error'));
                }
            }
        }
        
        // Fetch Recent Payments
        $recentPayments = NULL;
        if ($webfront->show_recent_payments) {
            $recentPayments = $this->Payments->find()->where(['webfront_id' => $webfront->id, 'status' => 1])->order(['payment_date' => 'DESC']);
        }

        // Get all validations
        $validations = $this->Validations->find()->select(['id', 'reg_exp', 'err_msg']);

        $this->set(compact(['webfront', 'validations', 'recentPayments']));
    }

    public function previewInvoice($uniqID = NULL) {
        $this->viewBuilder()->setLayout('');

        $query = $this->Payments->find()->where(['Payments.uniq_id' => $uniqID])->contain(['Webfronts.Users.MerchantPaymentGateways.PaymentGateways', 'Webfronts.Merchants', 'UploadedPaymentFiles']);

        if ($query->count() == 0) {
            throw new \Cake\Http\Exception\NotFoundException("Invoice Not Found!!");
        }

        $payment = $query->first();

        $payment->late_fee_amount = $payment->status == 1 ? $payment->late_fee_amount : $this->Custom->calLateFee($payment);
        $advance = empty($payment->reference_number) ? true : false;

        $this->set(compact('payment', 'advance'));

        $this->loadComponent('Mpdf');
        
        // Generate PDF Start        
        if (isset($_REQUEST['pdf']) && $_REQUEST['pdf'] == 'true') {
            $this->Mpdf->init(); // Initializing mPDF               
            $this->Mpdf->setFilename(INVOICE_PDF . "/" . sprintf("%04d", $payment->id) . '.pdf'); // Setting filename of output pdf file
            $this->Mpdf->setOutput('F'); // Setting output to I, D, F, S                
            $this->Mpdf->SetWatermarkText("Draft");
        }

        // Generate & Download PDF 
        if (isset($_REQUEST['download'])) {
            $this->Mpdf->init();
            $this->Mpdf->setFilename(INVOICE_PDF . "/" . sprintf("%04d", $payment->id) . '.pdf');
            $this->Mpdf->setOutput('DF');
            $this->Mpdf->SetWatermarkText("Draft");
        }
    }

    public function payuBasicWebfrontForm($uniqID) {
        $payment = $this->Payments->find()->where(['Payments.uniq_id' => $uniqID])->contain(['Webfronts.Merchants'])->first();
        $this->set(compact(['payment']));
    }

    public function payuResponse($uniqID = NULL) {
        if ($this->request->is('post')) {

            // Save Payment Gateway infromation to log table for future use.
            $this->PaymentGatewayResponses->saveToLog($_POST, $uniqID);

            $payment = $this->Payments->find()->where(['Payments.uniq_id' => $uniqID])->contain(['Webfronts.Users.MerchantPaymentGateways.PaymentGateways', 'Webfronts.Merchants', 'UploadedPaymentFiles'])->first();
            
            $status = $_POST["status"];
            $firstname = $_POST["firstname"];
            $amount = $_POST["amount"];
            $txnid = $_POST["txnid"];
            $key = $_POST["key"];
            $productinfo = $_POST["productinfo"];
            $email = $_POST["email"];
            $mode = $_POST['mode'];

            $key = $payment->webfront->user->merchant_payment_gateway->merchant_key;
            $salt = $payment->webfront->user->merchant_payment_gateway->merchant_salt;

            $postedHash = $_POST["hash"];

            $additionalCharges = 0;
            if (isset($_POST["additionalCharges"])) {
                $additionalCharges = $_POST["additionalCharges"];
                $retHashSeq = "{$additionalCharges}|{$salt}|{$status}|||||||||||{$email}|{$firstname}|{$productinfo}|{$amount}|{$txnid}|{$key}";
            } else {
                $retHashSeq = "{$salt}|{$status}|||||||||||{$email}|{$firstname}|{$productinfo}|{$amount}|{$txnid}|{$key}";
            }

            $hash = hash("sha512", $retHashSeq);

            if ($hash == $postedHash) {
                
                // Update Payments Table 
                $status = ($_POST['unmappedstatus'] == 'captured') ? 1 : 0;
                $paidAmount = $amount + $additionalCharges;
                $fileds = ["status" => $status, "unmappedstatus" => $_POST['unmappedstatus'], 'txn_id' => $txnid, "payment_date" => date('Y-m-d'), 'paid_amount' => $paidAmount, 'convenience_fee_amount' => $additionalCharges, 'mode' => $mode];
                $this->Payments->query()->update()->set($fileds)->where(['uniq_id' => $uniqID])->execute();
                
                // Generate Invoice PDF
                $this->Payments->geterateInvoicePdf($uniqID); 
                
                // Send Email To Customer
                $this->Payments->sendEmail($payment->id, 'PAYMENT_CONFIRMATION');
                
                $this->Flash->success(__('Payment Made Successfully!!'));
            } else {
                $this->Flash->success(__('Payment Failed!!'));
            }
        }
        return $this->redirect(HTTP_ROOT . 'preview-invoice/' . $uniqID);
    }

    public function razorPayResponse($uniqID) {

        if ($this->request->is('post')) {

            $data = $this->request->getData();

            // Save Payment Gateway infromation to log table for future use.
            $this->PaymentGatewayResponses->saveToLog($data, $uniqID);
           
            $data['txn_id'] = $data['razorpay_payment_id'];
            $data['status'] = 1;

            $payment = $this->Payments->find()->where(['uniq_id' => $data['uniq_id']])->first();

            $this->Payments->patchEntity($payment, $data);

            if ($this->Payments->save($payment)) {
                
                // Generate Invoice PDF
                $this->Payments->geterateInvoicePdf($uniqID); 
                
                // Send Email To Customer
                $this->Payments->sendEmail($payment->id, 'PAYMENT_CONFIRMATION');
                
                $this->Flash->success(__('Payment Made Successfully!!'));
            } else {
                $this->Flash->success(__('Payment Failed!!'));
            }
        }
        return $this->redirect(HTTP_ROOT . 'preview-invoice/' . $uniqID);
    }

    public function payNow($url) {

        if ($this->request->is('post')) {

            $data = $this->request->getData();

            $webfront = $this->Webfronts->find()->where(['url' => $url])->first();

            $payment = $this->Payments->newEntity();

            $customerFields = [];
            if (isset($data['payee_custom_fields'])) {
                foreach ($data['payee_custom_fields'] as $key => $value) {
                    $customerFields[$key] = [
                        'field' => $key,
                        'value' => $value
                    ];
                }
                $data['payee_custom_fields'] = json_encode($customerFields);
            } else {
                $data['payee_custom_fields'] = NULL;
            }



            $paymentFields = [];
            if (isset($data['payment_custom_fields'])) {
                foreach ($data['payment_custom_fields'] as $key => $value) {
                    if (!empty($data['payment_custom_fields'][$key])) {
                        $paymentFields[$key] = [
                            'field' => $key,
                            'value' => $value
                        ];
                    }
                }
                $data['payment_custom_fields'] = json_encode($paymentFields);
            } else {
                $data['payment_custom_fields'] = NULL;
            }


            $this->Payments->patchEntity($payment, $data);

            $payment->uniq_id = $this->Custom->generateUniqId();
            $payment->webfront_id = $webfront->id;
            $payment->payment_date = date("Y-m-d");

            if ($this->Payments->save($payment)) {
                return $this->redirect(HTTP_ROOT . 'preview-invoice/' . $payment->uniq_id);
            } else {
                $this->Flash->error(__('Error Occured, Please Try Again'));
                $this->redirect($this->referer());
            }
        }
    }

    public function payuAdvWebfrontForm($uniqID) {
        $payment = $this->Payments->find()->where(['Payments.uniq_id' => $uniqID])->contain(['Webfronts.Merchants'])->first();
        $this->set(compact(['payment']));
    }

    public function advanceWebfrontPaymentStatus($uniqID) {
        $this->viewBuilder()->setLayout('');
        $payment = $this->Payments->find()->where(['Payments.uniq_id' => $uniqID])->contain(['Webfronts.Merchants'])->first();

        $status = 'success';
        if ($status == 'success') {
            $this->Payments->sendEmail($payment->id, 'PAYMENT_CONFIRMATION');
        } elseif ($status == 'failure') {
            pr($status);
            exit;
        } else {
            pr($status);
            exit;
        }

        $this->set(compact(['payment', 'status']));
    }

    public function ajaxCheckEmailAvail() {
        $this->viewBuilder()->setLayout('ajax');
        $email = $this->request->getData('email');
        $emailExist = $this->Users->find()->where(['email' => $email])->count();
        if ($emailExist > 0) {
            echo "false";
        } else {
            echo "true";
        }
        exit;
    }

    public function downloadReceipt($uniqID) {
        $this->loadComponent('Mpdf');
        $payment = $this->Payments->find()->where(['Payments.uniq_id' => $uniqID])->contain(['Webfronts.Merchants'])->first();
        $this->set(compact('payment'));

        // Generate PDF Start        
        if (isset($_REQUEST['pdf']) && $_REQUEST['pdf'] == 'true') {
            $this->Mpdf->init(); // Initializing mPDF               
            $this->Mpdf->setFilename(INVOICE_PDF . "/" . sprintf("%04d", $payment->id) . '.pdf'); // Setting filename of output pdf file
            $this->Mpdf->setOutput('F'); // Setting output to I, D, F, S                
            $this->Mpdf->SetWatermarkText("Draft");
        }

        // Generate & Download PDF 
        if (isset($_REQUEST['download'])) {
            $this->Mpdf->init();
            $this->Mpdf->setFilename(INVOICE_PDF . "/" . sprintf("%04d", $payment->id) . '.pdf');
            $this->Mpdf->setOutput('DF');
            $this->Mpdf->SetWatermarkText("Draft");
        }
    }

    /*
     * Developer   :  Paratap Kishore Swain
     * Date        :  22nd Nov 2018
     * Description :  View & Download selected Advance Webfront Report.
     */

    public function advanceWebfrontReports() {
        $this->viewBuilder()->setLayout('default');  
        
        // Filter blank data & convert get to post request
        if ($this->request->is('post')) {
            $params = array_filter($this->request->getData());
            return $this->redirect(['controller' => 'Webfronts', 'action' => 'advanceWebfrontReports', '?' => $params]);
        }

        $queryParams = $this->request->getQueryParams();
        $webfrontID = NULL;
        
        if (isset($queryParams['webfront_id'])) {

            $webfrontID = $queryParams['webfront_id'];
            $conditions = ['Payments.webfront_id' => $webfrontID];            
            
            if (!empty($queryParams['date'])) {
                $conditions[] = ['DATE(Payments.created)' => $queryParams['date']];
            }

            if (!empty($queryParams['keyword'])) {
                $keyword = trim(urldecode($queryParams['keyword']));
                $conditions[] = ['OR' => ['Payments.name' => $keyword, 'Payments.email' => $keyword, 'Payments.phone' => $keyword]];
            }
            
            if (isset($queryParams['status'])) {
                $status = $queryParams['status'] == 1 ? 1 : 0;
                $conditions[] = ['Payments.status' => $status];
            }

            $payments = $this->Payments->find()->where($conditions)->order(['Payments.id' => 'DESC', 'name' => 'ASC']);

            if (isset($queryParams['download'])) {

                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $alphabets = range('A', 'Z');
                $styleArrayTitle = [
                    'font' => ['bold' => true],
                    'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
                ];

                $headers = ['Sl. No.', 'Unique ID', 'Name', 'Email', 'Phone', 'Total Amount', 'Payment Date', 'Transaction ID'];
                $customFields = false;

                foreach ($payments as $payment) {
                    if ($payment->payment_custom_fields != NULL) {
                        $customFields = true;
                        $sample = json_decode($payment->payment_custom_fields);
                        break;
                    }
                }

                $additionalCols = [];
                foreach ($payments as $payment) {
                    foreach ($sample as $field) {
                        $additionalCols[] = ucwords($field->field);
                    }
                    break;
                }
                array_splice($headers, 5, 0, $additionalCols);
                $numOfCols = count($headers);
                $sheet->fromArray($headers, NULL, 'A1');

                $sheetData = [];
                $i = 0;
                foreach ($payments as $payment) {
                    $sheetData[$i][] = ($i + 1);
                    $sheetData[$i][] = $payment->uniq_id;
                    $sheetData[$i][] = $payment->name;
                    $sheetData[$i][] = $payment->email;
                    $sheetData[$i][] = $payment->phone;
                    $sample = json_decode($payment->payment_custom_fields);
                    foreach ($sample as $field) {
                        $sheetData[$i][] = $field->value;
                    }
                    $sheetData[$i][] = $payment->paid_amount;
                    $sheetData[$i][] = ($payment->payment_date != NULL) ? date_format($payment->payment_date, "d/m/Y") : 'Payment has not been done!!';
                    $sheetData[$i][] = $payment->txn_id;
                    $i++;
                }
                $sheet->fromArray($sheetData, NULL, 'A2');

                for ($j = 0; $j < $numOfCols; $j++) {
                    $sheet->getColumnDimension($alphabets[$j])->setAutoSize(true);
                    $sheet->getStyle($alphabets[$j] . '1')->applyFromArray($styleArrayTitle);
                    $sheet->getStyle($alphabets[$j])->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
                }

                $writer = new Xlsx($spreadsheet);
                $file = "PaymentReport-" . time() . rand(1111, 9999) . ".xlsx";
                $writer->save('files/reports/' . $file);

                $filePath = WWW_ROOT . "files/reports/" . DS . $file;
                $response = $this->response->withFile($filePath, ['download' => TRUE, 'name' => $file]);
                return $response;
            }
            
            $config = ['limit' => 10];
            $payments = $this->Paginator->paginate($payments, $config);
        }

        $pageHeading = 'Advance Webfront Reports';
        $webfrontList = $this->Webfronts->find('list', ['keyField' => 'id', 'valueField' => 'url'])->where(['merchant_id' => $this->merchantId,'type' => 1]);
        
        $this->set(compact(['webfrontList', 'payments', 'webfrontID', 'pageHeading']));
    }

    public function webfrontMailTemplate($uniqID) {

        $webfront = $this->Webfronts->find()->where(['unique_id' => $uniqID]);

        $strURL = 'http://dev.raddyx.net/syndcollect/';
        $shortUrl = $this->Custom->shortUrlGenerator($strURL);
//        pr($shortUrl);exit;
    }

    /*
     * Developer   :  Paratap Kishore Swain
     * Date        :  22nd Nov 2018
     * Description :  View & Download selected Basic Webfront Report.
     */

    public function basicWebfrontReports() {
        $this->viewBuilder()->setLayout('default');
        $pageHeading = 'Basic Webfront Reports';
        
        // Filter blank data & convert get to post request
        if ($this->request->is('post')) {
            $params = array_filter($this->request->getData());
            return $this->redirect(['controller' => 'Webfronts', 'action' => 'basicWebfrontReports', '?' => $params]);
        }

        $webfrontId = NULL;
        $queryParams = $this->request->getQueryParams();
        $payments = NULL;
                
        if (isset($queryParams['webfront_id'])) {
            
            $webfrontId = $queryParams['webfront_id'];
            $conditions = ['Payments.webfront_id' => $queryParams['webfront_id']];

            if (!empty($queryParams['file_id'])) {
                $conditions[] = ['Payments.uploaded_payment_file_id' => $queryParams['file_id']];
            }

            if (!empty($queryParams['due_date'])) {
                $conditions[] = ['UploadedPaymentFiles.payment_cycle_date' => $queryParams['due_date']];
            }

            if (!empty($queryParams['keyword'])) {
                $keyword = trim(urldecode($queryParams['keyword']));
                $conditions[] = ['OR' => ['Payments.name' => $keyword, 'Payments.email' => $keyword, 'Payments.phone' => $keyword]];
            }
            
            if (isset($queryParams['status'])) {
                $status = $queryParams['status'] == 1 ? 1 : 0;
                $conditions[] = ['Payments.status' => $status];
            }

            $payments = $this->Payments->find()->where($conditions)->contain(['UploadedPaymentFiles'])->order(['Payments.id' => 'DESC', 'Payments.name' => 'ASC']);
           
            $webfront = $this->Webfronts->find()->where(['id' => $webfrontId])->first();

            if (isset($queryParams['download'])) {
                
                $objPHPExcel = new Spreadsheet();
                $sheet = $objPHPExcel->getActiveSheet();

                $count = 0;
                $head = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

                $sheet->getStyle("A1:{$head[$count]}1")->getAlignment()->applyFromArray([
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_FILL,
                ]);

                $sheet->getStyle("A1:{$head[$count]}1")->applyFromArray([
                    'font' => [ 'name' => 'Cambria', 'bold' => true, 'italic' => false, 'strikethrough' => false, 'color' => [ 'rgb' => '7, 7, 7']],
                    'quotePrefix' => true]);

                foreach (range('A', 'L') as $columnID) {
                    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
                }
                
                // SetHeading 
                $sheet->SetCellValue('A1', "Sr.No.");
                $sheet->SetCellValue('B1', "Name");
                $sheet->SetCellValue('C1', "Invoice Number");
                $sheet->SetCellValue('D1', "Reference Number");
                $sheet->SetCellValue('E1', "Email");
                $sheet->SetCellValue('F1', "Mobile No.");
                $sheet->SetCellValue('G1', "Total Amt");
                $sheet->SetCellValue('H1', "Payment Date");
                $sheet->SetCellValue('I1', "Payment Id");
                $sheet->SetCellValue('J1', "Paid Amount");
                $sheet->SetCellValue('K1', "Transaction Id");
                $sheet->SetCellValue('L1', "Mode");
                
                // Set Content
                $rowCount = 2;
                foreach ($payments as $payment) {
                    $sheet->SetCellValue('A' . $rowCount, ($rowCount - 1));
                    $sheet->SetCellValue('B' . $rowCount, $payment->name);
                    $sheet->SetCellValue('C' . $rowCount, sprintf('%04d', $payment->id));
                    $sheet->SetCellValue('D' . $rowCount, $payment->reference_number);
                    $sheet->SetCellValue('E' . $rowCount, $payment->email);
                    $sheet->SetCellValue('F' . $rowCount, $payment->phone);
                    $sheet->SetCellValue('G' . $rowCount, $payment->fee);
                    $sheet->SetCellValue('H' . $rowCount, $payment->payment_date);
                    $sheet->SetCellValue('I' . $rowCount, $payment->id);
                    $sheet->SetCellValue('J' . $rowCount, $payment->paid_amount);
                    $sheet->SetCellValue('K' . $rowCount, $payment->txn_id);
                    $sheet->SetCellValue('L' . $rowCount, $payment->mode);

                    $rowCount++;
                }

                $writer = new Xlsx($objPHPExcel);
                $fileName = "Transaction-Report-" . time() . ".xlsx";
                $filePath = WWW_ROOT . 'files/reports/' . DS . $fileName;
                $writer->save($filePath);

                $response = $this->response->withFile($filePath, ['download' => true, 'name' => $fileName]);
                return $response;
            }
            
            $config = ['limit' => 10];
            $payments = $this->Paginator->paginate($payments, $config);
        }

        $webfrontList = $this->Webfronts->find('list', ['keyField' => 'id', 'valueField' => 'url'])->where(['Webfronts.type' => 0]);
        $this->set(compact(['pageHeading', 'webfrontList', 'webfront', 'webfrontId', 'payments']));
    }    
    
    
    public function downloadQrCode($id) {
        
        $qrCode = $this->Webfronts->get($id)->qr;
        
        $filePath = WWW_ROOT . "files/qr/" . DS . $qrCode;
        $response = $this->response->withFile($filePath, ['download' => TRUE, 'name' => $qrCode]);
        return $response;
        
    }
    
    public function editInvoice($uniqID) {
        $this->viewBuilder()->setLayout('');
        $payment = $this->Payments->find()->where(['uniq_id' => $uniqID])->contain(['Webfronts'])->first();
        $this->set(compact('payment'));
    }

    public function ajaxEditInvoice() {
        $this->viewBuilder()->setLayout('');

        if ($this->request->is(['post'])) {

            $data = $this->request->getData();

            $payment = $this->Payments->find()->where(['uniq_id' => $data['uniq_id']])->first();
            $payment->fee = $data['fee'];
            $paymentFields = [];
            foreach ($data['payment_custom_fields'] as $index => $customField) {
                $key = key($customField);
                $paymentFields[] = [
                    'field' => $key,
                    'value' => $customField[$key],
                ];
            }
            $payment->payment_custom_fields = json_encode($paymentFields);

            if ($this->Payments->save($payment)) {
                
                // Send Email To Customer
                $this->Payments->sendEmail($payment->id, 'PAYMENT_NOTIFICATION');
                
                echo 'success';
            } else {
                echo 'error';
            }
        }
        exit;
    }

}
