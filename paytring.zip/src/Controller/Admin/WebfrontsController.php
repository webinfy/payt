<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

class WebfrontsController extends AdminController {

    public function initialize() {
        parent::initialize();

        // Load Models
        $this->loadModel('Users');
        $this->loadModel('Webfronts');
        $this->loadModel('Payments');
        $this->loadComponent('Paginator');

        // Set Layout
        $this->viewBuilder()->setLayout('admin');
    }

    /*
     * Developer   :  Mahesh Pradhan
     * Date        :  12th Nov 2018
     * Description :  Webfront Listing in merchant portal.
     */

    public function index() { 
        // Fetch all webfronts
        $fields = ['id', 'url', 'short_url', 'is_published', 'created', 'merchant_name' => 'Users.name'];
        $webfronts = $this->Webfronts->find()->select($fields)->contain(['Users']);

        $pageHeading = 'Webfronts';
        $this->set(compact(['pageHeading', 'webfronts']));
    }
    
    public function viewPayments() {
        $data = $this->request->getQuery();

        $webfrontID = 0;
        $payments = [];

        if (!empty($data['webfront_id'])) {
            $webfrontID = $data['webfront_id'];
            $conditions = ['webfront_id' => $webfrontID];
            $config = [
                'conditions' => $conditions,
                'limit' => 25,
                'order' => ['id' => 'DESC'],
                'contain' => [],
            ];
            $payments = $this->Paginator->paginate($this->Payments->find(), $config);
        }

        $pageHeading = 'Webfront Payments';
        $webfrontList = $this->Webfronts->find('list', ['keyField' => 'id', 'valueField' => 'url']);
        $this->set(compact(['pageHeading', 'payments', 'webfrontList', 'webfrontID']));
    }

}
