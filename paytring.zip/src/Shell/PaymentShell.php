<?php

namespace App\Shell;

use Cake\Console\Shell;
use Cake\Mailer\Email;

class PaymentShell extends Shell {

    public function main() {
        $this->out('Jay Jagannath.........');
    }

    /*
     * Dev : Pradeepta Khatoi
     * Date : 5 Dec 2016
     * Desc:  Very Failed Transactions
     */

    public function chekFailedTransactions() {

        //mail('pradeepta.raddyx@gmail.com', 'Syndicate Cronjob', 'Jay Jagannath....');

        $this->loadModel('Payments');
        $conditions = ['Payments.status' => 0, 'Payments.txn_id !=' => '', 'Payments.unmappedstatus IN' => ['auth', 'pending', 'bounced', 'dropped']];
        $payments = $this->Payments->find('all')->where($conditions)->order(['Payments.id' => 'DESC'])->contain(['Webfronts.Users.Merchants'])->limit(1000);
        foreach ($payments as $payment) {
            $var1 = $payment->txn_id;
            $key = $payment->webfront->user->merchant_profile->payu_key;
            $salt = $payment->webfront->user->merchant_profile->payu_salt;
            $command = "verify_payment";
            $hash_str = $key . '|' . $command . '|' . $var1 . '|' . $salt;
            $hash = strtolower(hash('sha512', $hash_str));
            $r = ['key' => $key, 'hash' => $hash, 'var1' => $var1, 'command' => $command];
            $qs = http_build_query($r);
            $apiUrl = PAYU_API_URL;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $qs);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            $jsonData = curl_exec($ch);
            if (curl_errno($ch)) {
                $sad = curl_error($ch);
                throw new \Exception($sad);
            }
            curl_close($ch);
            $data = json_decode($jsonData, TRUE);
            if ($data['status'] == 1) {
                $transactionDetails = $data['transaction_details'];
                foreach ($transactionDetails as $transactionDetail) {
                    if ($transactionDetail['status'] == 'success') {
                        $status = $this->Payments->query()->update()->set(['unmappedstatus' => $transactionDetail['unmappedstatus']])->where(['txn_id' => $payment->txn_id])->execute();
                        if ($transactionDetail['unmappedstatus'] == 'captured') {
                            $transactionId = $transactionDetail['txnid'];
                            $this->Payments->query()->update()->set(['status' => 1, 'unmappedstatus' => 'captured'])->where(['txn_id' => $payment->txn_id])->execute();
                        }
                    }
                }
            }
        }
        $this->out('Cron Executed!!');
    }

    /*
     * Dev : Pradeepta Khatoi
     * Date : 10 Nov 2016
     * Desc:  When a file will be imported successfully then immediate notification wemail will be sent to each customer by using this code.
     */

    public function sendEmailInBackground($id = NULL) {

        $this->loadModel('Payments');
        $this->loadModel('Webfronts');
        $this->loadModel('UploadedPaymentFiles');
        $this->loadModel('Users');
        $this->loadModel('AdminSettings');
        $this->loadModel('MailTemplates');

        $payments = $this->Payments->find('all')->where(['Payments.uploaded_payment_file_id' => $id, 'Payments.followup_counter' => 0]);
        pj($payments);exit;
        if ($payments->count()) {
            $adminSetting = $this->AdminSettings->find()->where(['id' => 1])->first();
            $mailTemplate = $this->MailTemplates->find()->where(['name' => 'PAYMENT_NOTIFICATION', 'is_active' => 1])->first();
            $uploadedPaymentFile = $this->UploadedPaymentFiles->get($id);
            $webfront = $this->Webfronts->find()->where(['Webfronts.id' => $uploadedPaymentFile->webfront_id])->contain(['Users'])->first();

            foreach ($payments as $payment) {
                if (!empty($payment->email)) {
                    $uniqId = $payment->uniq_id;
//                    $link = HTTP_ROOT . "customer/payments/make-payment/" . $uniqId;
                    //$link = HTTP_ROOT . "customer/login/" . $webfront->user->uniq_id;
                    $billAmount = $payment->fee;

                    $directLink = HTTP_ROOT . "webfront/$webfront->url";
                    // $viewTransLink = HTTP_ROOT . "customer/view-transactions/" . $webfront->user->uniq_id;

                    $message = $this->_formatEmail($mailTemplate['content'], [
                        'NAME' => $payment->name,
                        'MERCHANT' => $webfront->user->name,
                        'BILL_AMOUNT' => $billAmount,
                        'INVOICE_NO' => $payment->id,
                        'PAYMENT_LINK' => $link,
                        'DIRECT_LINK' => "<a href='{$directLink}'>{$directLink}</a>",
                        'VIEW_TRANSACTION_LINK' => "<a href='{$viewTransLink}'>{$viewTransLink}</a>",
                    ]);
                    $this->_sendEmail($payment->email, $adminSetting->from_email, $mailTemplate->subject, $message, $adminSetting->bcc_email);
                    $this->Payments->query()->update()->set(['followup_counter' => 'followup_counter' + 1])->where(['id' => $payment->id])->execute();
                }
            }
        }
        $this->out("Mail sent successfully!!");
    }

    /*
     * Dev : Pradeepta Khatoi
     * Date : 10 Nov 2016
     * Desc:  Cronjob For sending Email
     */

    public function sendBillNotifications() {

        $this->loadModel('Payments');
        $this->loadModel('MailTemplates');
        $this->loadModel('AdminSettings');
        $this->loadModel('Webfronts');
        $this->loadModel('Users');

        $conditions = [];
        $twoDayBefore = ['Webfronts.payment_cycle_date' => date('Y-m-d', strtotime(' +2 day'))];
        $oneDayBefore = ['Webfronts.payment_cycle_date' => date('Y-m-d', strtotime(' +1 day'))];
        $conditions = ['Webfronts.is_published' => 1, 'OR' => [$twoDayBefore, $oneDayBefore]];
        $webfronts = $this->Webfronts->find('all')->where($conditions)->contain(['Users']);

        if ($webfronts->count() > 0) {

            $mailTemplate = $this->MailTemplates->find()->where(['name' => 'PAYMENT_NOTIFICATION', 'is_active' => 1])->first();
            $adminSetting = $this->AdminSettings->find()->first();

            foreach ($webfronts as $webfront) {
                $payments = $this->Payments->find('all')->where(['Payments.webfront_id' => $webfront->id])->contain(['Webfronts', 'Webfronts.Users']);
                if ($payments->count() > 0) {
                    foreach ($payments as $payment) {
                        if ($payment->status == 0) {

                            $uniqId = $payment->uniq_id;
                            $link = HTTP_ROOT . "customer/payments/make-payment/" . $uniqId;

                            $directLink = HTTP_ROOT . "webfronts/basic/$payment->webfront->url";
                            $viewTransLink = HTTP_ROOT . "customer/view-transactions/" . $payment->webfront->user->uniq_id;

                            $billAmount = $payment->fee; // + $payment->convenience_fee_amount + $payment->late_fee_amount;

                            $message = $this->Custom->formatEmail($mailTemplate['content'], [
                                'NAME' => $payment->name,
                                'MERCHANT' => $webfront->user->name,
                                'BILL_AMOUNT' => $billAmount,
                                'INVOICE_NO' => $payment->id,
                                'PAYMENT_LINK' => $link,
                                'DIRECT_LINK' => "<a href='{$directLink}'>{$directLink}</a>",
                                'VIEW_TRANSACTION_LINK' => "<a href='{$viewTransLink}'>{$viewTransLink}</a>",
                            ]);

                            $this->_sendEmail($payment->email, $adminSetting->from_email, $mailTemplate->subject, $message);
                            $this->Payments->query()->update()->set(['followup_counter' => 'followup_counter' + 1])->where(['id' => $payment->id])->execute();
                        }
                    }
                }
            }
        }

        $this->out('Mail Sent Successfully');
    }

    public function _formatCustomField($url) {
        if ($url) {
            $url = trim($url);
            $value = preg_replace("![^a-z0-9]+!i", "_", $url);
            $value = trim($value, "_");
            return strtolower($value);
        }
    }

    public function _formatEmail($msg, $arrData) {
        foreach ($arrData as $key => $value) {
            if (strstr($msg, "[" . $key . "]")) {
                $msg = str_replace("[" . $key . "]", $value, $msg);
            }
        }
        if (strstr($msg, "[SITE_NAME]")) {
            $msg = str_replace('[SITE_NAME]', "<a href='" . HTTP_ROOT . "'>" . SITE_NAME . "</a>", $msg);
        }
        return $msg;
    }

    public function _sendEmail($to, $from, $subject, $message, $bcc = '', $files = NULL, $header = 1, $footer = 1) {

        if ($header) {
            $hdr = '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
    <html>
    <head>
    <title>' . SITE_NAME . '</title>
    </head>
    <body>
    <table width="750" style="font-family:arial helvetica sans-serif" border="0" cellspacing="0" cellpadding="0">
    <tbody>       
        <tr> <td bgcolor="#3f51b5" style="padding: 5px 10px; text-align: center;"><img alt="" src="' . HTTP_ROOT . 'images/logo.png"/></td></tr>         
        <tr> <td style="border:1px solid #c6c6c6"><table width="100%" border="0" cellspacing="0" cellpadding="0"> <tbody>
            <tr>
                <td style="padding-left:12px;padding-right:12px;font-family:trebuchet ms,arial;font-size:13px">';
        }
        if ($footer) {
            $ftr = '</td>
            </tr>
            </tbody>
        </table></td>
        </tr>        
    </tbody>
    </table>
    </body>
    </html>';
        }

        $message = $hdr . $message . $ftr;
        $to = $this->_emailText($to);
        $bcc = $this->_emailText($bcc);
        $subject = $this->_emailText($subject);
        $message = $this->_emailText($message);
        $message = str_replace("<script>", "&lt;script&gt;", $message);
        $message = str_replace("</script>", "&lt;/script&gt;", $message);
        $message = str_replace("<SCRIPT>", "&lt;script&gt;", $message);
        $message = str_replace("</SCRIPT>", "&lt;/script&gt;", $message);

        if (LIVE) {
            //Send Email by using Cakephp3.x
            $email = new Email('default');
            $email->setFrom([$from => SITE_NAME]);
            if (!empty($files)) {
                $email->attachments($files);
            }
            $email->setEmailFormat('html');
            $email->setTemplate(NULL);
            $email->setTo($to);
            if (!empty($bcc)) {
                $email->setBcc($bcc);
            }
            $email->setSubject($subject);
            $email->send($message);
        } else {
            if (!file_exists(WWW_ROOT . "tempemails/")) {
                mkdir(WWW_ROOT . "tempemails/", 0777, true);
            }
            $fileName = md5(uniqid()) . time() . ".html";
            $logFile = fopen(WWW_ROOT . "tempemails/" . $fileName, "w");
            $txt = "$message  \n";
            fwrite($logFile, $txt);
            fclose($logFile);
            return TRUE;
        }
    }

    public function _emailText($value) {
        $value = stripslashes(trim($value));
        $value = str_replace('"', "\"", $value);
        $value = str_replace('"', "\"", $value);
        $value = preg_replace('/[^(\x20-\x7F)\x0A]*/', '', $value);
        return stripslashes($value);
    }

}
