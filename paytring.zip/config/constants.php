<?php
define("SITE_NAME", "PayTring");
define("ADMIN_EMAIL", "admin@paytring.com");
define("FROM_EMAIL", "info@paytring.com");
define("BCC_EMAIL", "pradeepta.raddyx@gmail.com");
define("SUPPORT_EMAIL", "support@paytring.com");
