<?php

function sanitize($input) {
    if (is_array($input)) {
        foreach ($input as $key => $value) {
            if (is_array($input)) {
                $input[$key] = sanitize($value);
            } else {
                $input[$key] = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value);
            }
        }
    } else {
        $input = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $input);
    }
    return $input;
}

function formatPrice($price, $decimal = 2) {
    return number_format((float) $price, $decimal, '.', '') + 0;
}

 function generateUniqId($id = NULL) {
    $uniq = uniqid(rand()) . uniqid(rand());
    if ($id) {
        return md5($uniq . time() . $id);
    } else {
        return md5($uniq . time());
    }
}

function getFirstError($errors) {
    $errMsg = "Error Occured!!";
    try {
        $errors = array_shift($errors);
        $errMsg = array_shift($errors);
    } catch (\Exception $ex) {
        
    }
    return $errMsg;
}

function sendResponse($data) {
    echo json_encode($data);
    exit;
}

function getTxnID($id = NULL) {
    $newTransactionID = "PT" . time() . rand(1111, 9999);
    return $newTransactionID;
}

function getRealIpAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function formatInvoiceNo($id) {    
    return sprintf('%04d', $id);
}